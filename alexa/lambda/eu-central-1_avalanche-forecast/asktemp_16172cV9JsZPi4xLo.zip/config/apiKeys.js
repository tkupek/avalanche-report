module.exports = Object.freeze({
    googleGeocodingAPI: 'AIzaSyDjjFYS6ZLmqOMWi8YcswIYsinC1RHhhfE'
});